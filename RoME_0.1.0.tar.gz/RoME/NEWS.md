NEWS
================
Bitetto Isabella - COISPA
25 August 2020

Fixes 0.1.2
-----

1. "windows" was eliminated from NAMESPACE;
2. The spelling of GSAs, (7:102, 7:427), MEDITS (3:45, 7:80, 7:148, 7:216, 7:320, 7:449), RoME (7:270, 7:388) is verified and its correctness is confirmed;
3. The time for running examples is due to the number of functions involved in the package.
